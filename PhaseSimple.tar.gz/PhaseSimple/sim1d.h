using namespace std;

class Csim1d :: Csim2d {
    public:
        Csim1d();
        ~Csim1d();
        void Extruder(void);
        int solve1d();
};
